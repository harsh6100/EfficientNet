!. Please run the following command on terminal
    python main.py --image cat.jfif