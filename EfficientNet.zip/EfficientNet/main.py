import numpy as np
import tensorflow
import cv2
import argparse


EfficientNetB0 = tensorflow.keras.applications.EfficientNetB0
EfficientNetB3 = tensorflow.keras.applications.EfficientNetB3
EfficientNetB4 = tensorflow.keras.applications.EfficientNetB4
EfficientNetB7 = tensorflow.keras.applications.EfficientNetB7
image = tensorflow.keras.preprocessing.image
decode_predictions = tensorflow.keras.applications.imagenet_utils.decode_predictions
preprocess_input = tensorflow.keras.applications.imagenet_utils.preprocess_input


def process_image(img_path, size):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (size, size))

    x = np.expand_dims(img, axis=0)
    x = preprocess_input(x)
    return x


arg_parse = argparse.ArgumentParser()
arg_parse.add_argument('--image', required=True, help='path to input image')
args = arg_parse.parse_args()
modelb0 = EfficientNetB0(weights='imagenet')
modelb3 = EfficientNetB3(weights='imagenet')
modelb4 = EfficientNetB4(weights='imagenet')
modelb7 = EfficientNetB7(weights='imagenet')
processed_image0 = process_image(args.image, 224)
processed_image3 = process_image(args.image, 300)
processed_image4 = process_image(args.image, 380)
processed_image7 = process_image(args.image, 600)
pred0 = modelb0.predict(processed_image0)
pred3 = modelb3.predict(processed_image3)
pred4 = modelb4.predict(processed_image4)
pred7 = modelb7.predict(processed_image7)

print("\nEfficientNetB0 Prediction..............")
pd = decode_predictions(pred0, top=1)
print("Class - {}  Accuracy - {}".format(pd[0][0][1], pd[0][0][2]))
print("\n")

print("EfficientNetB3 Prediction..............")
pd=decode_predictions(pred3, top=1)
print("Class - {}  Accuracy - {}".format(pd[0][0][1], pd[0][0][2]))

print("\n")

print("EfficientNetB4 Prediction..............")
pd = decode_predictions(pred4, top=1)
print("Class - {}  Accuracy - {}".format(pd[0][0][1], pd[0][0][2]))

print("\n")

print("EfficientNetB7 Prediction..............")
pd = decode_predictions(pred7, top=1)
print("Class - {}  Accuracy - {}".format(pd[0][0][1], pd[0][0][2]))

print("\n")


